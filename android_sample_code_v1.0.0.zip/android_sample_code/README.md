# Samsung Wallet Container Android Sample Code
Samsung Wallet Card is an e-wallet service allows customers to use Samsung devices to clip various digitized contents on Samsung Wallet. Users can add their own ticket, coupon, boarding pass and other types of data into Samsung Wallet using an 'Add to Wallet' link via multiple online channels such as App, Web, E-mail, or Social Media.\
This is a sample code to help partners integrate to Samsung Wallet.

---

## Check Availability
Check availability by calling the API <i>'6.7 Check service available devices'</i>, then determine how to show up the 'Add to Wallet' button on a user device.  
> A. If the 'available' value on response is 'true', it indicates 'SUPPORT'.\
> B. If the 'available' value on response is 'false', it indicates 'NOT SUPPORT'.

### Response example
```json
{
  "resultCode": "0",
  "resultMessage": "SUCCESS",
  "available": "true",
  "supportKR": "true"
}
```

---

## Button Images
Get button image resources from a repository depending on a service environment.

| Type  | Locale | Version       | Image                                                                                     |
|-------|--------|---------------|-------------------------------------------------------------------------------------------|
| btnSW | N/A    | normal        | <img src="https://kr-cdn-gpp.mcsvc.samsung.com/lib/wallet-card.png" width="300">          |
|       |        | normal,dark   | <img src="https://kr-cdn-gpp.mcsvc.samsung.com/lib/wallet-card-dark.png" width="300">     |
|       |        | vertical      | <img src="https://kr-cdn-gpp.mcsvc.samsung.com/lib/wallet-card-ver.png" width="300">      |
|       |        | vertical,dark | <img src="https://kr-cdn-gpp.mcsvc.samsung.com/lib/wallet-card-ver-dark.png" width="300"> |

For more button image details, see <i>'6.6 Image resources'</i> in the API specification.

---

## Data To Fill
```java
public class MainActivity extends AppCompatActivity {
    final String modelName = Build.MODEL;
    final String countryCode = "US"; // (optional) country code (ISO_3166-2)
    final String serviceType = "WALLET"; // (mandatory, fixed) for Samsung Wallet
    final String partnerCode = "[ PARTNER CODE ]"; // (mandatory) same as partnerId (Partner ID)
    final String impressionUrl = "[ IMPRESSION URL ]";
    final String clickURL = "[ CLICK URL ]";
    final String intentURL /*[ INTENT URL ]*/ = "https://a.swallet.link/atw/v1/[ CARD ID ]#Clip?cdata=[ CDATA ]";
}
```
Find `PARTNER CODE`, `IMPRESSION URL`, `CLICK URL`, `INTENT URL`, `Card ID` and `CDATA` in the partner portal.
